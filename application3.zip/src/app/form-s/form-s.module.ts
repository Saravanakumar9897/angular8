import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { FormSRoutingModule } from './form-s-routing.module';
import { FormSComponent } from './form-s.component';


@NgModule({
  declarations: [FormSComponent],
  imports: [
    CommonModule,
    FormSRoutingModule
  ]
})
export class FormSModule { }
