import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-form-s',
  templateUrl: './form-s.component.html',
  styleUrls: ['./form-s.component.css']
})
export class FormSComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
