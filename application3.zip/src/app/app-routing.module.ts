import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { AppComponent } from './app.component';


const routes: Routes = [
		{
			path:'home',
			loadChildren: ()=> import('./home/home.module').then(H => H.HomeModule)
		},
		{
			path:'menu',
			loadChildren: ()=> import('./menu/menu.module').then(M => M.MenuModule)
		},
		{
			path: 'login',
			loadChildren: ()=> import('./login/login.module').then(L => L.LoginModule)
		},
		{
			path: 'forms',
			loadChildren: ()=> import('./form1/form1.module').then(L => L.Form1Module)
		},
		{
			path:'',
			component: AppComponent
		},
		{
			path:'**',
			component: AppComponent
		}
		];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
