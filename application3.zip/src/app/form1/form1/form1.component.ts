import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, FormArray } from '@angular/forms';

@Component({
  selector: 'app-form1',
  templateUrl: './form1.component.html',
  styleUrls: ['./form1.component.css']
})
export class Form1Component implements OnInit {

orderForm: FormGroup;
items: FormArray;



 createItem(): FormGroup {
  return this.formBuilder.group({
    name: '',
    description: '',
    price: ''
  });
}

  constructor( private formBuilder:FormBuilder ) { }

  ngOnInit() {

  	this.orderForm = this.formBuilder.group({
	    items: this.formBuilder.array([ this.createItem() ])
	});
 
  }



  addItem(): void {
	  this.items = this.orderForm.get('items') as FormArray;
	  this.items.push(this.createItem());
  }
  	
 	removeItemm(index){
		this.items.removeAt(index);
	}
	submit(){
			console.log(this.orderForm.value);
	}
}
